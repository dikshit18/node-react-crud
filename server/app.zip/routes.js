const routes = require("express").Router();

routes.get("/", (req, res) => {
  console.log("Response");
  res.json(req.apiGateway.event);
});
routes.post("/products");
routes.delete("/products");
routes.put("/products");
module.exports = routes;
